
import AuthPage from "./components/AuthPage";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import UploadPanel from "./components/UploadPanel";
import DocumentPanel from "./components/DocumentPanel";
import ChatWindow from "./components/ChatWindow";
import * as api from "./services/api";
import { useAuth } from "./hooks/useAuth";
import { useDocuments } from "./hooks/useDocuments";
import { useChat } from "./hooks/useChat";
import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { Plus, LogOut } from "lucide-react";

import {
  newThreadId,
  getCurrentUser,
  clearToken,
  getToken,
} from "./lib/api";

import "./style.css";

function App() {
  const [authMode, setAuthMode] = useState("login");
  const [email, setEmail] = useState("user1@test.com");
  const [password, setPassword] = useState("test1234");
  const {
  user,
  setUser,
  authStatus,
  setAuthStatus,
  login,
  register,
  logout,
} = useAuth();

  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);


const {
  documents,
  summary,
  status,
  setStatus,
  refreshDocuments,
  refreshSummary,
  upload,
  remove,
} = useDocuments();

  const {
  messages,
  setMessages,
  question,
  setQuestion,
  threads,
  refreshThreads,
  loadThread,
  ask,
} = useChat(threadId);

  const [threadId, setThreadId] = useState(newThreadId());


  function getThreadStorageKey(userEmail) {
  return `thread_id_${userEmail}`;
  }

  useEffect(() => {
    async function checkLogin() {
      if (!getToken()) return;

      try {
        const currentUser = await getCurrentUser();
        setUser(currentUser);
      } catch {
        clearToken();
      }
    }

    checkLogin();
  }, []);


useEffect(() => {
  if (!user) return;

  refreshThreads();
  refreshDocuments();
  refreshSummary();
}, [threadId, user]);

  async function handleAuth(e) {
    e.preventDefault();

    try {
      let currentUser;

      if (authMode === "register") {
        currentUser = await register(email, password);
      } else {
        currentUser = await login(email, password);
      }

      const savedThreadId =
        localStorage.getItem(getThreadStorageKey(currentUser.email)) ||
        newThreadId();

      localStorage.setItem(
        getThreadStorageKey(currentUser.email),
        savedThreadId
      );

      setThreadId(savedThreadId);
      setMessages([]);
    } catch (e) {

    }
  }

  


  function handleLogout() {
  logout();

  const freshThreadId = newThreadId();

  setThreadId(freshThreadId);
  setMessages([]);
  setQuestion("");
}


  function startNewChat() {
    const id = newThreadId();
    localStorage.setItem(getThreadStorageKey(user.email), id);
    setThreadId(id);
    setMessages([]);
    setQuestion("");
    setStatus("");
  }

 

  if (!user) {
  return (
    <AuthPage
      authMode={authMode}
      setAuthMode={setAuthMode}
      email={email}
      setEmail={setEmail}
      password={password}
      setPassword={setPassword}
      handleAuth={handleAuth}
      authStatus={authStatus}
    />
  );
}

  return (
    <main className="layout">
      <Sidebar
        user={user}
        threadId={threadId}
        threads={threads}
        startNewChat={startNewChat}
        loadThread={loadThread}
        handleLogout={handleLogout}
      />

      <section className="app">
        <section className="hero">
          <h1>Production RAG Assistant</h1>
          <p>
            Multi-user RAG with PostgreSQL, pgvector, JWT auth, private documents,
            source citations, streaming answers, and evaluation dashboard.
          </p>
        </section>

        <Dashboard summary={summary} />

        <UploadPanel
          files={files}
          setFiles={setFiles}
          handleUpload={() => upload(files, setLoading)}
          loading={loading}
          status={status}
        />

        <DocumentPanel
          documents={documents}
          handleDeleteDocument={remove}
        />

        <ChatWindow
          messages={messages}
          question={question}
          setQuestion={setQuestion}
          handleAsk={(e) => {
            e.preventDefault();
            ask(question, refreshSummary, setLoading);
          }}
          loading={loading}
        />
      </section>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);  