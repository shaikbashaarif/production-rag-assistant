import { useState } from "react";
import {
  loginUser,
  registerUser,
  getCurrentUser,
  clearToken,
} from "../lib/api";

export function useAuth() {
  const [user, setUser] = useState(null);
  const [authStatus, setAuthStatus] = useState("");

  async function login(email, password) {
    setAuthStatus("");

    try {
      await loginUser(email, password);
      const currentUser = await getCurrentUser();

      setUser(currentUser);

      return currentUser;
    } catch (e) {
      setAuthStatus(e.message);
      throw e;
    }
  }

  async function register(email, password) {
    await registerUser(email, password);
    return login(email, password);
  }

  function logout() {
    clearToken();
    setUser(null);
  }

  return {
    user,
    setUser,
    authStatus,
    setAuthStatus,
    login,
    register,
    logout,
  };
}