import { useState } from "react";
import {
  streamQuestion,
  listThreads,
  getThreadMessages,
} from "../lib/api";

export function useChat(threadId) {
  const [messages, setMessages] = useState([]);
  const [question, setQuestion] = useState("");
  const [threads, setThreads] = useState([]);

  async function refreshThreads() {
    try {
      setThreads(await listThreads());
    } catch {}
  }

  async function loadThread(id) {
    const rows = await getThreadMessages(id);

    setMessages(
      rows.map((r) => ({
        role: r.role,
        text: r.content,
        sources: r.sources || [],
      }))
    );
  }

  async function ask(
    userQuestion,
    refreshSummary,
    setLoading
  ) {
    if (!userQuestion.trim()) return;

    setQuestion("");

    setMessages((m) => [
      ...m,
      {
        role: "user",
        text: userQuestion,
        sources: [],
      },
      {
        role: "assistant",
        text: "",
        sources: [],
      },
    ]);

    setLoading(true);

    try {
      await streamQuestion(
        userQuestion,
        threadId,

        (token) => {
          setMessages((m) => {
            const copy = [...m];

            copy[copy.length - 1] = {
              ...copy[copy.length - 1],
              text:
                copy[copy.length - 1].text + token,
            };

            return copy;
          });
        },

        (sources) => {
          setMessages((m) => {
            const copy = [...m];

            copy[copy.length - 1] = {
              ...copy[copy.length - 1],
              sources,
            };

            return copy;
          });
        }
      );

      await refreshThreads();
      await refreshSummary();
    } catch (e) {
      setMessages((m) => [
        ...m,
        {
          role: "assistant",
          text: `Error: ${e.message}`,
          sources: [],
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return {
  messages,
  setMessages,
  question,
  setQuestion,
  threads,
  refreshThreads,
  loadThread,
  ask,
};
}