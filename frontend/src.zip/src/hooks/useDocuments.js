import { useState } from "react";
import {
  uploadMultipleDocuments,
  listDocuments,
  deleteDocument,
  getEvaluationSummary,
} from "../lib/api";

export function useDocuments() {
  const [documents, setDocuments] = useState([]);
  const [summary, setSummary] = useState(null);
  const [status, setStatus] = useState("");

  async function refreshDocuments() {
    try {
      setDocuments(await listDocuments());
    } catch {}
  }

  async function refreshSummary() {
    try {
      setSummary(await getEvaluationSummary());
    } catch {}
  }

  async function upload(files, setLoading) {
    if (!files.length) return;

    setLoading(true);
    setStatus("Uploading and indexing documents...");

    try {
      const results = await uploadMultipleDocuments(files);

      const totalChunks = results.reduce(
        (sum, item) => sum + item.chunks_added,
        0
      );

      setStatus(
        `${results.length} document(s) indexed successfully. Total chunks: ${totalChunks}`
      );

      await refreshDocuments();
      await refreshSummary();
    } catch (e) {
      setStatus(`Upload failed: ${e.message}`);
    } finally {
      setLoading(false);
    }
  }

  async function remove(documentId) {
    if (!confirm("Delete this document and its vector chunks?")) return;

    try {
      await deleteDocument(documentId);

      await refreshDocuments();
      await refreshSummary();

      setStatus("Document deleted successfully.");
    } catch (e) {
      setStatus(`Delete failed: ${e.message}`);
    }
  }

  return {
    documents,
    setDocuments,
    summary,
    setSummary,
    status,
    setStatus,
    refreshDocuments,
    refreshSummary,
    upload,
    remove,
  };
}